

-- T?o b?ng NhanVien
CREATE TABLE NhanVien (
    MaNhanVien VARCHAR(255) PRIMARY KEY,
    TenNhanVien NVARCHAR(100) NOT NULL,
    MatKhau VARCHAR(255) NOT NULL,
    ChucVu NVARCHAR(50) NOT NULL
);

-- T?o b?ng NhaCungCap
CREATE TABLE NhaCungCap (
    MaNhaCungCap VARCHAR(255) PRIMARY KEY,
    TenNhaCungCap NVARCHAR(100) NOT NULL,
    DiaChi NVARCHAR(200),
    SoDienThoai NVARCHAR(20),
    Email NVARCHAR(100)
);

-- T?o b?ng ThongTinPhim
CREATE TABLE ThongTinPhim (
    MaPhim VARCHAR(255) PRIMARY KEY,
    TenPhim NVARCHAR(100) NOT NULL,
    TheLoai NVARCHAR(50),
    DoTuoi INT,
    ThoiLuong INT NOT NULL,
    MaNhaCungCap VARCHAR(255) NOT NULL,
    FOREIGN KEY (MaNhaCungCap) REFERENCES NhaCungCap(MaNhaCungCap)
);


-- T?o b?ng LoaiVe
CREATE TABLE LoaiVe (
    MaLoaiVe VARCHAR(255) PRIMARY KEY,
    TenLoaiVe NVARCHAR(50) NOT NULL
);

-- T?o b?ng Ve
CREATE TABLE Ve (
    MaVe VARCHAR(255) PRIMARY KEY,
    TenVe NVARCHAR(50) NOT NULL,
    GiaVe DECIMAL(10, 2) NOT NULL,
    MaLoaiVe VARCHAR(255) NOT NULL,
    FOREIGN KEY (MaLoaiVe) REFERENCES LoaiVe(MaLoaiVe)
);

-- T?o b?ng PhongChieu
CREATE TABLE PhongChieu (
    MaPhongChieu VARCHAR(255) PRIMARY KEY,
    TenPhongChieu NVARCHAR(50) NOT NULL
);

-- T?o b?ng LichChieu
CREATE TABLE LichChieu (
    MaLichChieu VARCHAR(255) PRIMARY KEY,
    GioChieu DATETIME NOT NULL,
    MaPhim VARCHAR(255) NOT NULL,
    MaPhongChieu VARCHAR(255) NOT NULL,
    FOREIGN KEY (MaPhim) REFERENCES ThongTinPhim(MaPhim),
    FOREIGN KEY (MaPhongChieu) REFERENCES PhongChieu(MaPhongChieu)
);



-- T?o b?ng GheNgoi
CREATE TABLE GheNgoi (
    MaGhe VARCHAR(255) PRIMARY KEY,
    SoGhe INT NOT NULL,
    LoaiGhe NVARCHAR(50),
    MaPhongChieu VARCHAR(255) NOT NULL,
    FOREIGN KEY (MaPhongChieu) REFERENCES PhongChieu(MaPhongChieu)
);



-- T?o b?ng KhachHang
CREATE TABLE KhachHang (
    MaKhachHang VARCHAR(255) PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    GioiTinh NVARCHAR(10),
    Email NVARCHAR(100),
    SoDienThoai NVARCHAR(20),
    DiemTichLuy INT DEFAULT 0,
    LoaiThanhVien NVARCHAR(50)
);

-- Th�m d? li?u v�o b?ng NhanVien
INSERT INTO NhanVien (MaNhanVien, TenNhanVien, MatKhau, ChucVu)
VALUES 
    ('NV01', 'Nguyen Van A', 'password123', 'QuanLy'),
    ('NV02', 'Tran Thi B', 'password456', 'NhanVien');

-- Th�m d? li?u v�o b?ng NhaCungCap
INSERT INTO NhaCungCap (MaNhaCungCap, TenNhaCungCap, DiaChi, SoDienThoai, Email)
VALUES 
    ('NCC01', 'Nha Cung Cap 1', '123 Le Loi', '0909123456', 'ncc1@gmail.com'),
    ('NCC02', 'Nha Cung Cap 2', '456 Hai Ba Trung', '0912345678', 'ncc2@gmail.com');

-- Th�m d? li?u v�o b?ng ThongTinPhim
INSERT INTO ThongTinPhim (MaPhim, TenPhim, TheLoai, DoTuoi, ThoiLuong, MaNhaCungCap)
VALUES 
    ('P01', 'Phim A', 'Hanh Dong', 16, 120, 'NCC01'),
    ('P02', 'Phim B', 'Hai Huoc', 13, 90, 'NCC02');

-- Th�m d? li?u v�o b?ng LoaiVe
INSERT INTO LoaiVe (MaLoaiVe, TenLoaiVe)
VALUES 
    ('LV01', 'Ve Thuong'),
    ('LV02', 'Ve VIP');

-- Th�m d? li?u v�o b?ng Ve
INSERT INTO Ve (MaVe, TenVe, GiaVe, MaLoaiVe)
VALUES 
    ('V01', 'Ve Thuong P01', 70000, 'LV01'),
    ('V02', 'Ve VIP P01', 120000, 'LV02');

-- Th�m d? li?u v�o b?ng PhongChieu
INSERT INTO PhongChieu (MaPhongChieu, TenPhongChieu)
VALUES 
    ('PC01', 'Phong 1'),
    ('PC02', 'Phong 2');

-- Th�m d? li?u v�o b?ng GheNgoi
INSERT INTO GheNgoi (MaGhe, SoGhe, LoaiGhe, MaPhongChieu)
VALUES 
    ('G01', 1, 'Thuong', 'PC01'),
    ('G02', 2, 'VIP', 'PC02');

-- Th�m d? li?u v�o b?ng KhachHang
INSERT INTO KhachHang (MaKhachHang, HoTen, GioiTinh, Email, SoDienThoai, DiemTichLuy, LoaiThanhVien)
VALUES 
    ('KH01', 'Le Van C', 'Nam', 'levanc@gmail.com', '0987123456', 100, 'Vang'),
    ('KH02', 'Pham Thi D', 'Nu', 'phamthid@gmail.com', '0978123456', 200, 'Bach Kim');

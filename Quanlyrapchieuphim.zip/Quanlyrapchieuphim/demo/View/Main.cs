﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void NhanVien_Click(object sender, EventArgs e)
        {
            NhanVien nv = new NhanVien();
            nv.ShowDialog();
        }

        private void kháchHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KhachHang kh = new KhachHang();
            kh.ShowDialog();
        }

        private void nhàCungCấpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NhaCungCap ncc = new NhaCungCap();
            ncc.ShowDialog();
        }

        private void loạiVéToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoaiVe lv = new LoaiVe();
            lv.ShowDialog();
        }

        private void phòngChiếuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PhongChieu pc = new PhongChieu();
            pc.ShowDialog();
        }

        private void thôngTinPhimToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThongTinPhim ttp = new ThongTinPhim();
            ttp.ShowDialog();
        }

        private void lịchChiếuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LichChieu lc = new LichChieu();
            lc.ShowDialog();
        }

        private void véToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ve v = new Ve();
            v.ShowDialog();
        }

        private void ghếNgồiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GheNgoi gn = new GheNgoi();
            gn.ShowDialog();
        }
    }
}

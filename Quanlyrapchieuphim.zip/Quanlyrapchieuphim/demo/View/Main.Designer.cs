﻿
namespace demo.View
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.quảnLýPhimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.thôngTinPhimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lịchChiếuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhàCungCấpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.véToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loạiVéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ghếNgồiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.phòngChiếuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoDoanhThuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoTồnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chiTiêuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.statusStrip1.Location = new System.Drawing.Point(0, 815);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1215, 22);
            this.statusStrip1.TabIndex = 20;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // quảnLýPhimToolStripMenuItem
            // 
            this.quảnLýPhimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinPhimToolStripMenuItem,
            this.lịchChiếuToolStripMenuItem,
            this.nhàCungCấpToolStripMenuItem});
            this.quảnLýPhimToolStripMenuItem.Image = global::demo.Properties.Resources.Movie_Studio_icon_icons_com_76891;
            this.quảnLýPhimToolStripMenuItem.Name = "quảnLýPhimToolStripMenuItem";
            this.quảnLýPhimToolStripMenuItem.Size = new System.Drawing.Size(212, 38);
            this.quảnLýPhimToolStripMenuItem.Text = "Quản lý phim";
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýPhimToolStripMenuItem,
            this.quảnLýVéToolStripMenuItem,
            this.quảnLýHệThốngToolStripMenuItem,
            this.báoCáoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 25);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1215, 42);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1215, 25);
            this.toolStrip1.TabIndex = 21;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // thôngTinPhimToolStripMenuItem
            // 
            this.thôngTinPhimToolStripMenuItem.Image = global::demo.Properties.Resources.brochure_pamphlet_film_icon_190861;
            this.thôngTinPhimToolStripMenuItem.Name = "thôngTinPhimToolStripMenuItem";
            this.thôngTinPhimToolStripMenuItem.Size = new System.Drawing.Size(359, 44);
            this.thôngTinPhimToolStripMenuItem.Text = "Thông tin phim";
            this.thôngTinPhimToolStripMenuItem.Click += new System.EventHandler(this.thôngTinPhimToolStripMenuItem_Click);
            // 
            // lịchChiếuToolStripMenuItem
            // 
            this.lịchChiếuToolStripMenuItem.Image = global::demo.Properties.Resources._4288563cinemaclapperboardmedianetworksocial_115793_115721;
            this.lịchChiếuToolStripMenuItem.Name = "lịchChiếuToolStripMenuItem";
            this.lịchChiếuToolStripMenuItem.Size = new System.Drawing.Size(359, 44);
            this.lịchChiếuToolStripMenuItem.Text = "Lịch chiếu";
            this.lịchChiếuToolStripMenuItem.Click += new System.EventHandler(this.lịchChiếuToolStripMenuItem_Click);
            // 
            // nhàCungCấpToolStripMenuItem
            // 
            this.nhàCungCấpToolStripMenuItem.Image = global::demo.Properties.Resources._4288584andbusinessfinancepersonalportfolioprofileresume_115772_115741;
            this.nhàCungCấpToolStripMenuItem.Name = "nhàCungCấpToolStripMenuItem";
            this.nhàCungCấpToolStripMenuItem.Size = new System.Drawing.Size(359, 44);
            this.nhàCungCấpToolStripMenuItem.Text = "Nhà cung cấp";
            this.nhàCungCấpToolStripMenuItem.Click += new System.EventHandler(this.nhàCungCấpToolStripMenuItem_Click);
            // 
            // quảnLýVéToolStripMenuItem
            // 
            this.quảnLýVéToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.véToolStripMenuItem,
            this.loạiVéToolStripMenuItem,
            this.ghếNgồiToolStripMenuItem,
            this.phòngChiếuToolStripMenuItem});
            this.quảnLýVéToolStripMenuItem.Image = global::demo.Properties.Resources.discount2_115851_115818;
            this.quảnLýVéToolStripMenuItem.Name = "quảnLýVéToolStripMenuItem";
            this.quảnLýVéToolStripMenuItem.Size = new System.Drawing.Size(182, 38);
            this.quảnLýVéToolStripMenuItem.Text = "Quản lý vé";
            // 
            // véToolStripMenuItem
            // 
            this.véToolStripMenuItem.Image = global::demo.Properties.Resources.ticket_icon_icons_com_52351;
            this.véToolStripMenuItem.Name = "véToolStripMenuItem";
            this.véToolStripMenuItem.Size = new System.Drawing.Size(359, 44);
            this.véToolStripMenuItem.Text = "Vé";
            this.véToolStripMenuItem.Click += new System.EventHandler(this.véToolStripMenuItem_Click);
            // 
            // loạiVéToolStripMenuItem
            // 
            this.loạiVéToolStripMenuItem.Image = global::demo.Properties.Resources.Ticket_icon_30266;
            this.loạiVéToolStripMenuItem.Name = "loạiVéToolStripMenuItem";
            this.loạiVéToolStripMenuItem.Size = new System.Drawing.Size(359, 44);
            this.loạiVéToolStripMenuItem.Text = "Loại vé";
            this.loạiVéToolStripMenuItem.Click += new System.EventHandler(this.loạiVéToolStripMenuItem_Click);
            // 
            // ghếNgồiToolStripMenuItem
            // 
            this.ghếNgồiToolStripMenuItem.Image = global::demo.Properties.Resources.cinema_chair_seat_seating_armchairs_icon_190827;
            this.ghếNgồiToolStripMenuItem.Name = "ghếNgồiToolStripMenuItem";
            this.ghếNgồiToolStripMenuItem.Size = new System.Drawing.Size(359, 44);
            this.ghếNgồiToolStripMenuItem.Text = "Ghế ngồi";
            this.ghếNgồiToolStripMenuItem.Click += new System.EventHandler(this.ghếNgồiToolStripMenuItem_Click);
            // 
            // phòngChiếuToolStripMenuItem
            // 
            this.phòngChiếuToolStripMenuItem.Image = global::demo.Properties.Resources.stage_theater_show_performance_cinema_icon_190832;
            this.phòngChiếuToolStripMenuItem.Name = "phòngChiếuToolStripMenuItem";
            this.phòngChiếuToolStripMenuItem.Size = new System.Drawing.Size(359, 44);
            this.phòngChiếuToolStripMenuItem.Text = "Phòng chiếu";
            this.phòngChiếuToolStripMenuItem.Click += new System.EventHandler(this.phòngChiếuToolStripMenuItem_Click);
            // 
            // quảnLýHệThốngToolStripMenuItem
            // 
            this.quảnLýHệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nhânViênToolStripMenuItem,
            this.kháchHàngToolStripMenuItem});
            this.quảnLýHệThốngToolStripMenuItem.Image = global::demo.Properties.Resources._1490201154_hierarchy_82309;
            this.quảnLýHệThốngToolStripMenuItem.Name = "quảnLýHệThốngToolStripMenuItem";
            this.quảnLýHệThốngToolStripMenuItem.Size = new System.Drawing.Size(282, 38);
            this.quảnLýHệThốngToolStripMenuItem.Text = "Quản lý người dùng";
            // 
            // nhânViênToolStripMenuItem
            // 
            this.nhânViênToolStripMenuItem.Image = global::demo.Properties.Resources.review_group_team_worker_profile_office_employee_icon_261691;
            this.nhânViênToolStripMenuItem.Name = "nhânViênToolStripMenuItem";
            this.nhânViênToolStripMenuItem.Size = new System.Drawing.Size(275, 44);
            this.nhânViênToolStripMenuItem.Text = "Nhân viên";
            this.nhânViênToolStripMenuItem.Click += new System.EventHandler(this.NhanVien_Click);
            // 
            // kháchHàngToolStripMenuItem
            // 
            this.kháchHàngToolStripMenuItem.Image = global::demo.Properties.Resources._1490201150_client_82317;
            this.kháchHàngToolStripMenuItem.Name = "kháchHàngToolStripMenuItem";
            this.kháchHàngToolStripMenuItem.Size = new System.Drawing.Size(275, 44);
            this.kháchHàngToolStripMenuItem.Text = "Khách hàng";
            this.kháchHàngToolStripMenuItem.Click += new System.EventHandler(this.kháchHàngToolStripMenuItem_Click);
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.báoCáoNhậpToolStripMenuItem,
            this.báoCáoDoanhThuToolStripMenuItem,
            this.báoCáoTồnToolStripMenuItem,
            this.chiTiêuToolStripMenuItem});
            this.báoCáoToolStripMenuItem.Image = global::demo.Properties.Resources._1486564180_finance_financial_report_81493;
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            this.báoCáoToolStripMenuItem.Size = new System.Drawing.Size(151, 38);
            this.báoCáoToolStripMenuItem.Text = "Báo cáo";
            // 
            // báoCáoNhậpToolStripMenuItem
            // 
            this.báoCáoNhậpToolStripMenuItem.Image = global::demo.Properties.Resources.businessapplication_distributor_report_document_negocio_2319;
            this.báoCáoNhậpToolStripMenuItem.Name = "báoCáoNhậpToolStripMenuItem";
            this.báoCáoNhậpToolStripMenuItem.Size = new System.Drawing.Size(351, 44);
            this.báoCáoNhậpToolStripMenuItem.Text = "Báo cáo nhập";
            // 
            // báoCáoDoanhThuToolStripMenuItem
            // 
            this.báoCáoDoanhThuToolStripMenuItem.Image = global::demo.Properties.Resources._1491254084_6document_report_82918;
            this.báoCáoDoanhThuToolStripMenuItem.Name = "báoCáoDoanhThuToolStripMenuItem";
            this.báoCáoDoanhThuToolStripMenuItem.Size = new System.Drawing.Size(351, 44);
            this.báoCáoDoanhThuToolStripMenuItem.Text = "Báo cáo doanh thu";
            // 
            // báoCáoTồnToolStripMenuItem
            // 
            this.báoCáoTồnToolStripMenuItem.Image = global::demo.Properties.Resources.business_table_order_report_history_2332;
            this.báoCáoTồnToolStripMenuItem.Name = "báoCáoTồnToolStripMenuItem";
            this.báoCáoTồnToolStripMenuItem.Size = new System.Drawing.Size(351, 44);
            this.báoCáoTồnToolStripMenuItem.Text = "Báo cáo tồn";
            // 
            // chiTiêuToolStripMenuItem
            // 
            this.chiTiêuToolStripMenuItem.Image = global::demo.Properties.Resources.Sales_report_25411;
            this.chiTiêuToolStripMenuItem.Name = "chiTiêuToolStripMenuItem";
            this.chiTiêuToolStripMenuItem.Size = new System.Drawing.Size(351, 44);
            this.chiTiêuToolStripMenuItem.Text = "Chi tiêu";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 837);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "Main";
            this.Text = "Main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem quảnLýPhimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinPhimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lịchChiếuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhàCungCấpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýVéToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem véToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loạiVéToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ghếNgồiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoDoanhThuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoTồnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiTiêuToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripMenuItem phòngChiếuToolStripMenuItem;
    }
}
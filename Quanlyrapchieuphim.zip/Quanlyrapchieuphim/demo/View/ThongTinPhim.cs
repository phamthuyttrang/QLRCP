﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class ThongTinPhim : Form, IView
    {
        ThongTinPhimController controller;
        ThongTinPhimModel thongtinphim;

        internal IModel newthongtinphim { get; private set; }
        public object updatedThongTinPhim { get; private set; }

        public ThongTinPhim()
        {
            InitializeComponent();
            controller = new ThongTinPhimController();

            thongtinphim = new ThongTinPhimModel();
        }


        public void GetDataFromText()
        {
            thongtinphim.MaPhim = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = thongtinphim.MaPhim;

        }

        private void LoadData()
        {

            List<ThongTinPhimModel> thongtinphims = controller.GetAllThongTinPhims();


            dataGridView1.DataSource = thongtinphims;

        }
        private void ThongTinPhim_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaPhim"].Value.ToString();
                textBox2.Text = row.Cells["TenPhim"].Value.ToString();
                textBox3.Text = row.Cells["TheLoai"].Value.ToString();
                textBox4.Text = row.Cells["DoTuoi"].Value.ToString();
                textBox5.Text = row.Cells["ThoiLuong"].Value.ToString();
                textBox6.Text = row.Cells["MaNhaCungCap"].Value.ToString();
                
            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            
        }




        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                ThongTinPhimModel newThongTinPhim = new ThongTinPhimModel();
                newThongTinPhim.MaPhim = textBox1.Text;
                newThongTinPhim.TenPhim = textBox2.Text;
                newThongTinPhim.TheLoai = textBox3.Text;
                newThongTinPhim.DoTuoi = int.Parse(textBox4.Text);
                newThongTinPhim.ThoiLuong = int.Parse(textBox5.Text);
                newThongTinPhim.MaNhaCungCap = textBox6.Text;


                if (controller.Create(newThongTinPhim))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                ThongTinPhimModel updatedThongTinPhim = new ThongTinPhimModel();
                updatedThongTinPhim.MaPhim = textBox1.Text;
                updatedThongTinPhim.TenPhim = textBox2.Text;
                updatedThongTinPhim.TheLoai = textBox3.Text;
                updatedThongTinPhim.DoTuoi = int.Parse(textBox4.Text);
                updatedThongTinPhim.ThoiLuong = int.Parse(textBox5.Text);
                updatedThongTinPhim.MaNhaCungCap = textBox6.Text;



                if (controller.Update(updatedThongTinPhim))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                ThongTinPhimModel thongtinphimToDelete = new ThongTinPhimModel();
                thongtinphimToDelete.MaPhim = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa thông tin phim có MaPhim {thongtinphimToDelete.MaPhim}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(thongtinphimToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}

﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class Ve : Form, IView
    {
        VeController controller;
        VeModel ve;

        internal IModel newve { get; private set; }
        public object updatedVe { get; private set; }

        public Ve()
        {
            InitializeComponent();
            controller = new VeController();

            ve = new VeModel();
        }


        public void GetDataFromText()
        {
            ve.MaVe = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = ve.MaVe;

        }

        private void LoadData()
        {

            List<VeModel> ves = controller.GetAllVes();


            dataGridView1.DataSource = ves;

        }
        private void Ve_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaVe"].Value.ToString();
                textBox2.Text = row.Cells["TenVe"].Value.ToString();
                textBox3.Text = row.Cells["GiaVe"].Value.ToString();
                textBox4.Text = row.Cells["MaLoaiVe"].Value.ToString();
                

            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
          

        }







        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                VeModel newVe = new VeModel();
                newVe.MaVe = textBox1.Text;
                newVe.TenVe = textBox2.Text;
                newVe.GiaVe = decimal.Parse(textBox3.Text);
                newVe.MaLoaiVe = textBox4.Text;



                if (controller.Create(newVe))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                VeModel updatedVe = new VeModel();
                updatedVe.MaVe = textBox1.Text;
                updatedVe.TenVe = textBox2.Text;
                updatedVe.GiaVe = decimal.Parse(textBox3.Text);
                updatedVe.MaLoaiVe = textBox4.Text;




                if (controller.Update(updatedVe))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                VeModel veToDelete = new VeModel();
                veToDelete.MaVe = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa vé có MaVe {veToDelete.MaVe}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(veToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}

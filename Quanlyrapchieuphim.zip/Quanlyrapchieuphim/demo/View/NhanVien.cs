﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class NhanVien : Form, IView
    {
        NhanVienController controller;
        NhanVienModel nhanvien;

        internal IModel newNhanVien { get; private set; }
        public object updatedNhanVien { get; private set; }

        public NhanVien()
        {
            InitializeComponent();
            controller = new NhanVienController();

            nhanvien = new NhanVienModel();
        }


        public void GetDataFromText()
        {
            nhanvien.MaNhanVien = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = nhanvien.MaNhanVien;

        }

        private void LoadData()
        {

            List<NhanVienModel> nhanviens = controller.GetAllNhanViens();


            dataGridView1.DataSource = nhanviens;

        }
        private void NhanVien_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaNhanVien"].Value.ToString();
                textBox2.Text = row.Cells["TenNhanVien"].Value.ToString();
                textBox3.Text = row.Cells["MatKhau"].Value.ToString();
                textBox4.Text = row.Cells["ChucVu"].Value.ToString();

            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }



       

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                NhanVienModel newNhanVien = new NhanVienModel();
                newNhanVien.MaNhanVien = textBox1.Text;
                newNhanVien.TenNhanVien = textBox2.Text;
                newNhanVien.MatKhau = textBox3.Text;
                newNhanVien.ChucVu = textBox4.Text;


                if (controller.Create(newNhanVien))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                NhanVienModel updatedNhanVien = new NhanVienModel();
                updatedNhanVien.MaNhanVien = textBox1.Text;
                updatedNhanVien.TenNhanVien = textBox2.Text;
                updatedNhanVien.MatKhau = textBox3.Text;
                updatedNhanVien.ChucVu = textBox4.Text;



                if (controller.Update(updatedNhanVien))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                NhanVienModel nhanvienToDelete = new NhanVienModel();
                nhanvienToDelete.MaNhanVien = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa chi nhánh có MaChiNhanh {nhanvienToDelete.MaNhanVien}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(nhanvienToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        
    }
}

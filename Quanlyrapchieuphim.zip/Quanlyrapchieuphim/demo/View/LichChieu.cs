﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class LichChieu : Form, IView
    {
        LichChieuController controller;
        LichChieuModel lichchieu;

        internal IModel newlichchieu { get; private set; }
        public object updatedLichChieu { get; private set; }

        public LichChieu()
        {
            InitializeComponent();
            controller = new LichChieuController();

            lichchieu = new LichChieuModel();
        }


        public void GetDataFromText()
        {
            lichchieu.MaLichChieu = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = lichchieu.MaLichChieu;

        }

        private void LoadData()
        {

            List<LichChieuModel> lichchieus = controller.GetAllLichChieus();


            dataGridView1.DataSource = lichchieus;

        }
        private void LichChieu_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaLichChieu"].Value.ToString();
                dateTimePicker1.Value = (DateTime)row.Cells["GioChieu"].Value;
                textBox2.Text = row.Cells["MaPhim"].Value.ToString();
                textBox3.Text = row.Cells["MaPhongChieu"].Value.ToString();
                

            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            
            

        }







        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                LichChieuModel newLichChieu = new LichChieuModel();
                newLichChieu.MaLichChieu = textBox1.Text;
                newLichChieu.GioChieu = DateTime.Now;
                newLichChieu.MaPhim = textBox2.Text;
                newLichChieu.MaPhongChieu = textBox3.Text;



                if (controller.Create(newLichChieu))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                LichChieuModel updatedLichChieu = new LichChieuModel();
                updatedLichChieu.MaLichChieu = textBox1.Text;
                updatedLichChieu.GioChieu = DateTime.Now;
                updatedLichChieu.MaPhim = textBox2.Text;
                updatedLichChieu.MaPhongChieu = textBox3.Text;




                if (controller.Update(updatedLichChieu))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                LichChieuModel lichchieuToDelete = new LichChieuModel();
                lichchieuToDelete.MaLichChieu = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa lịch chiếu có MaLichChieu {lichchieuToDelete.MaLichChieu}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(lichchieuToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}

﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class LoaiVe : Form, IView
    {
        LoaiVeController controller;
        LoaiVeModel loaive;

        internal IModel newloaive { get; private set; }
        public object updatedLoaiVe { get; private set; }

        public LoaiVe()
        {
            InitializeComponent();
            controller = new LoaiVeController();

            loaive = new LoaiVeModel();
        }


        public void GetDataFromText()
        {
            loaive.MaLoaiVe = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = loaive.MaLoaiVe;

        }

        private void LoadData()
        {

            List<LoaiVeModel> loaives = controller.GetAllLoaiVes();


            dataGridView1.DataSource = loaives;

        }
        private void LoaiVe_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaLoaiVe"].Value.ToString();
                textBox2.Text = row.Cells["TenLoaiVe"].Value.ToString();
               

            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            

        }






        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                LoaiVeModel newLoaiVe = new LoaiVeModel();
                newLoaiVe.MaLoaiVe = textBox1.Text;
                newLoaiVe.TenLoaiVe = textBox2.Text;



                if (controller.Create(newLoaiVe))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                LoaiVeModel updatedLoaiVe = new LoaiVeModel();
                updatedLoaiVe.MaLoaiVe = textBox1.Text;
                updatedLoaiVe.TenLoaiVe = textBox2.Text;




                if (controller.Update(updatedLoaiVe))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                LoaiVeModel loaiveToDelete = new LoaiVeModel();
                loaiveToDelete.MaLoaiVe = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa loại vé có MaLoaiVe {loaiveToDelete.MaLoaiVe}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(loaiveToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}

﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class KhachHang : Form, IView
    {
        KhachHangController controller;
        KhachHangModel khachhang;

        internal IModel newkhachhang { get; private set; }
        public object updatedKhachHang { get; private set; }

        public KhachHang()
        {
            InitializeComponent();
            controller = new KhachHangController();

            khachhang = new KhachHangModel();
        }


        public void GetDataFromText()
        {
            khachhang.MaKhachHang = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = khachhang.MaKhachHang;

        }

        private void LoadData()
        {

            List<KhachHangModel> khachhangs = controller.GetAllKhachHangs();


            dataGridView1.DataSource = khachhangs;

        }
        private void KhachHang_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaKhachHang"].Value.ToString();
                textBox2.Text = row.Cells["HoTen"].Value.ToString();
                textBox3.Text = row.Cells["GioiTinh"].Value.ToString();
                textBox4.Text = row.Cells["Email"].Value.ToString();
                textBox5.Text = row.Cells["SoDienThoai"].Value.ToString();
                textBox6.Text = row.Cells["DiemTichLuy"].Value.ToString();
                textBox7.Text = row.Cells["LoaiThanhVien"].Value.ToString();
            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }




        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                KhachHangModel newKhachHang = new KhachHangModel();
                newKhachHang.MaKhachHang = textBox1.Text;
                newKhachHang.HoTen = textBox2.Text;
                newKhachHang.GioiTinh = textBox3.Text;
                newKhachHang.Email = textBox4.Text;
                newKhachHang.SoDienThoai = textBox5.Text;
                newKhachHang.DiemTichLuy = int.Parse(textBox6.Text);
                newKhachHang.LoaiThanhVien = textBox7.Text;

                if (controller.Create(newKhachHang))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                KhachHangModel updatedKhachHang = new KhachHangModel();
                updatedKhachHang.MaKhachHang = textBox1.Text;
                updatedKhachHang.HoTen = textBox2.Text;
                updatedKhachHang.GioiTinh = textBox3.Text;
                updatedKhachHang.Email = textBox4.Text;
                updatedKhachHang.SoDienThoai = textBox5.Text;
                updatedKhachHang.DiemTichLuy = int.Parse(textBox6.Text);
                updatedKhachHang.LoaiThanhVien = textBox7.Text;


                if (controller.Update(updatedKhachHang))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                KhachHangModel khachhangToDelete = new KhachHangModel();
                khachhangToDelete.MaKhachHang = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa khách hàng có MaKhachHang {khachhangToDelete.MaKhachHang}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(khachhangToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        
    }
}

﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class GheNgoi : Form, IView
    {
        GheNgoiController controller;
        GheNgoiModel ghengoi;

        internal IModel newghengoi { get; private set; }
        public object updatedGheNgoi { get; private set; }

        public GheNgoi()
        {
            InitializeComponent();
            controller = new GheNgoiController();

            ghengoi = new GheNgoiModel();
        }


        public void GetDataFromText()
        {
            ghengoi.MaGhe = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = ghengoi.MaGhe;

        }

        private void LoadData()
        {

            List<GheNgoiModel> ghengois = controller.GetAllGheNgois();


            dataGridView1.DataSource = ghengois;

        }
        private void GheNgoi_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaGhe"].Value.ToString();
                textBox2.Text = row.Cells["SoGhe"].Value.ToString();
                textBox3.Text = row.Cells["LoaiGhe"].Value.ToString();
                textBox4.Text = row.Cells["MaPhongChieu"].Value.ToString();


            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();


        }





        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                GheNgoiModel newGheNgoi = new GheNgoiModel();
                newGheNgoi.MaGhe = textBox1.Text;
                newGheNgoi.SoGhe = int.Parse(textBox2.Text);
                newGheNgoi.LoaiGhe = textBox3.Text;
                newGheNgoi.MaPhongChieu = textBox4.Text;



                if (controller.Create(newGheNgoi))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                GheNgoiModel updatedGheNgoi = new GheNgoiModel();
                updatedGheNgoi.MaGhe = textBox1.Text;
                updatedGheNgoi.SoGhe = int.Parse(textBox2.Text);
                updatedGheNgoi.LoaiGhe = textBox3.Text;
                updatedGheNgoi.MaPhongChieu = textBox4.Text;




                if (controller.Update(updatedGheNgoi))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                GheNgoiModel ghengoiToDelete = new GheNgoiModel();
                ghengoiToDelete.MaGhe = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa ghế ngồi có MaGhe {ghengoiToDelete.MaGhe}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(ghengoiToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        
    }
}

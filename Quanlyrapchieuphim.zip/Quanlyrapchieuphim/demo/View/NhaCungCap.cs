﻿using demo.Controller;
using demo.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.View
{
    public partial class NhaCungCap : Form, IView
    {
        NhaCungCapController controller;
        NhaCungCapModel nhacungcap;

        internal IModel newnhacungcap { get; private set; }
        public object updatedNhaCungCap { get; private set; }

        public NhaCungCap()
        {
            InitializeComponent();
            controller = new NhaCungCapController();

            nhacungcap = new NhaCungCapModel();
        }


        public void GetDataFromText()
        {
            nhacungcap.MaNhaCungCap = textBox1.Text;

        }

        public void SetDataToText()
        {
            textBox1.Text = nhacungcap.MaNhaCungCap;

        }

        private void LoadData()
        {

            List<NhaCungCapModel> nhacungcaps = controller.GetAllNhaCungCaps();


            dataGridView1.DataSource = nhacungcaps;

        }
        private void NhaCungCap_Load(object sender, EventArgs e)
        {
            LoadData();
            dataGridView1.CellClick += dataGridView1_CellContentClick_1;

        }


        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaNhaCungCap"].Value.ToString();
                textBox2.Text = row.Cells["TenNhaCungCap"].Value.ToString();
                textBox3.Text = row.Cells["DiaChi"].Value.ToString();
                textBox4.Text = row.Cells["SoDienThoai"].Value.ToString();
                textBox5.Text = row.Cells["Email"].Value.ToString();
                
            }
        }



        private void ClearTextBoxes()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
          
        }




        

     
      
        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                NhaCungCapModel newNhaCungCap = new NhaCungCapModel();
                newNhaCungCap.MaNhaCungCap = textBox1.Text;
                newNhaCungCap.TenNhaCungCap = textBox2.Text;
                newNhaCungCap.DiaChi = textBox3.Text;
                newNhaCungCap.SoDienThoai = textBox4.Text;
                newNhaCungCap.Email = textBox5.Text;


                if (controller.Create(newNhaCungCap))
                {
                    MessageBox.Show("Thêm thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                NhaCungCapModel updatedNhaCungCap = new NhaCungCapModel();
                updatedNhaCungCap.MaNhaCungCap = textBox1.Text;
                updatedNhaCungCap.TenNhaCungCap = textBox2.Text;
                updatedNhaCungCap.DiaChi = textBox3.Text;
                updatedNhaCungCap.SoDienThoai = textBox4.Text;
                updatedNhaCungCap.Email = textBox5.Text;



                if (controller.Update(updatedNhaCungCap))
                {
                    MessageBox.Show("Cập nhật thông tin thành công!");
                    LoadData();
                    ClearTextBoxes();
                }
                else
                {
                    MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng kiểm tra lại.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                NhaCungCapModel nhacungcapToDelete = new NhaCungCapModel();
                nhacungcapToDelete.MaNhaCungCap = textBox1.Text;




                DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa nhà cung cấp có MaNhaCungCap {nhacungcapToDelete.MaNhaCungCap}?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (controller.Delete(nhacungcapToDelete))
                    {
                        MessageBox.Show("Xóa thông tin thành công!");
                        LoadData();
                        ClearTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa thông tin thất bại. Vui lòng kiểm tra lại.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}

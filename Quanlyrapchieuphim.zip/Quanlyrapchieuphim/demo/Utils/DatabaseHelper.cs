﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Utils
{
    internal class DatabaseHelper
    {
        public static SqlConnection GetConnection()
        {
            string sqlString = "Data Source=LAPTOP-RS8BA07G\\SQLDB;Initial Catalog=QLRCPdemo;Integrated Security=True";
            SqlConnection conn = new SqlConnection(sqlString);
            return conn;
        }
        public static DataTable ExecuteQuery(string query)
        {
            using (SqlConnection connection = GetConnection())
            {
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                return dataTable;
            }
        }
    }
}

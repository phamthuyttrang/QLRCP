﻿using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal class VeController : IController
    {
        private List<IModel> _items;
        public List<VeModel> GetAllVes()
        {
            List<VeModel> ves = new List<VeModel>();
            string query = "SELECT * FROM Ve";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                VeModel ve = new VeModel
                {
                    MaVe = row["MaVe"].ToString(),
                    TenVe = row["TenVe"].ToString(),
                    GiaVe = decimal.Parse(row["GiaVe"].ToString()),
                    MaLoaiVe = row["MaLoaiVe"].ToString(),
                  


                };



                ves.Add(ve);
            }

            return ves;
        }
        public VeController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                VeModel ve = (VeModel)model;
                string query = "INSERT INTO Ve (MaVe, TenVe, GiaVe, MaLoaiVe) VALUES (@MaVe, @TenVe, @GiaVe, @MaLoaiVe)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaVe", ve.MaLoaiVe);
                        cmd.Parameters.AddWithValue("@TenVe", ve.TenVe);
                        cmd.Parameters.AddWithValue("@GiaVe", ve.GiaVe);
                        cmd.Parameters.AddWithValue("@MaLoaiVe", ve.MaLoaiVe);
                        


                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                VeModel ve = (VeModel)model;
                string MaVe = ve.MaVe;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deleteveQuery = "DELETE FROM Ve WHERE MaVe = @MaVe";
                            using (SqlCommand deleteveCmd = new SqlCommand(deleteveQuery, connection, transaction))
                            {
                                deleteveCmd.Parameters.AddWithValue("@MaVe", MaVe);
                                deleteveCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from Ve", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    VeModel model = new VeModel();
                    model.MaVe = reader["MaVe"].ToString();
                    model.TenVe = reader["TenVe"].ToString();
                    model.GiaVe = decimal.Parse(reader["GiaVe"].ToString());
                    model.MaLoaiVe = reader["MaLoaiVe"].ToString();
                   

                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaVe)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaVe)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                VeModel ve = (VeModel)model;
                string query = "UPDATE Ve SET TenVe = @TenVe, GiaVe = @GiaVe, MaLoaiVe = @MaLoaiVe WHERE MaVe = @MaVe";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaVe", ve.MaVe);
                        cmd.Parameters.AddWithValue("@TenVe", ve.TenVe);
                        cmd.Parameters.AddWithValue("@GiaVe", ve.GiaVe);
                        cmd.Parameters.AddWithValue("@MaLoaiVe", ve.MaLoaiVe);
                        



                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaVe)
        {
            return true;
        }
        public bool Read(Object MaVe)
        {

            return true;
        }

        IModel IController.Read(object MaVe)
        {
            throw new NotImplementedException();
        }


    }
}

﻿using demo.Controller;
using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.Controller
{
    internal class NhanVienController : IController
    {
        private List<IModel> _items;
        public List<NhanVienModel> GetAllNhanViens()
        {
            List<NhanVienModel> nhanviens = new List<NhanVienModel>();
            string query = "SELECT * FROM NhanVien";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                NhanVienModel nhanvien = new NhanVienModel
                {
                    MaNhanVien = row["MaNhanVien"].ToString(),
                    TenNhanVien = row["TenNhanVien"].ToString(),
                    MatKhau = row["MatKhau"].ToString(),
                    ChucVu = row["ChucVu"].ToString(),

                };



                nhanviens.Add(nhanvien);
            }

            return nhanviens;
        }
        public NhanVienController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                NhanVienModel nhanvien = (NhanVienModel)model;
                string query = "INSERT INTO NhanVien (MaNhanVien, TenNhanVien, MatKhau, ChucVu) VALUES (@MaNhanVien, @TenNhanVien, @MatKhau, @ChucVu)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaNhanVien", nhanvien.MaNhanVien);
                        cmd.Parameters.AddWithValue("@TenNhanVien", nhanvien.TenNhanVien);
                        cmd.Parameters.AddWithValue("@MatKhau", nhanvien.MatKhau);
                        cmd.Parameters.AddWithValue("@ChucVu", nhanvien.ChucVu);


                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                NhanVienModel nhanvien = (NhanVienModel)model;
                string MaNhanVien = nhanvien.MaNhanVien;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deletenhanvienQuery = "DELETE FROM NhanVien WHERE MaNhanVien = @MaNhanVien";
                            using (SqlCommand deletenhanvienCmd = new SqlCommand(deletenhanvienQuery, connection, transaction))
                            {
                                deletenhanvienCmd.Parameters.AddWithValue("@MaNhanVien", MaNhanVien);
                                deletenhanvienCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from NhanVien", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    NhanVienModel model = new NhanVienModel();
                    model.MaNhanVien = reader["MaNhanVien"].ToString();

                    model.TenNhanVien = reader["TenNhanVien"].ToString();
                    model.MatKhau = reader["MatKhau"].ToString();
                    model.ChucVu = reader["ChucVu"].ToString();
                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaNhanVien)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaNhanVien)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                NhanVienModel nhanvien = (NhanVienModel)model;
                string query = "UPDATE NhanVien SET TenNhanVien = @TenNhanVien, MatKhau = @MatKhau, ChucVu = @ChucVu WHERE MaNhanVien = @MaNhanVien";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaNhanVien", nhanvien.MaNhanVien);
                        cmd.Parameters.AddWithValue("@TenNhanVien", nhanvien.TenNhanVien);
                        cmd.Parameters.AddWithValue("@MatKhau", nhanvien.MatKhau);

                        cmd.Parameters.AddWithValue("@ChucVu", nhanvien.ChucVu);



                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaNhanVien)
        {
            return true;
        }

       
        public bool Read(Object MaNhanVien)
        {

            return true;
        }


        IModel IController.Read(object MaNhanVien)
        {
            throw new NotImplementedException();
        }


    }
}

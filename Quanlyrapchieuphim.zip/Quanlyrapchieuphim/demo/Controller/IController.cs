﻿using demo.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal interface IController
    {
        List<IModel> Items { get; }
        bool Create(IModel model);

        bool Update(IModel model);
        bool Delete(IModel model);
        IModel Read(Object model);
        bool Load();
        bool Load(Object model);
        bool IsExist(Object model);

    }
}

﻿using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal class GheNgoiController : IController
    {
        private List<IModel> _items;
        public List<GheNgoiModel> GetAllGheNgois()
        {
            List<GheNgoiModel> ghengois = new List<GheNgoiModel>();
            string query = "SELECT * FROM GheNgoi";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                GheNgoiModel ghengoi = new GheNgoiModel
                {
                    MaGhe = row["MaGhe"].ToString(),
                    SoGhe = int.Parse(row["SoGhe"].ToString()),
                    LoaiGhe = row["LoaiGhe"].ToString(),
                    MaPhongChieu = row["MaPhongChieu"].ToString(),



                };



                ghengois.Add(ghengoi);
            }

            return ghengois;
        }
        public GheNgoiController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                GheNgoiModel ghengoi = (GheNgoiModel)model;
                string query = "INSERT INTO GheNgoi (MaGhe, SoGhe, LoaiGhe, MaPhongChieu) VALUES (@MaGhe, @SoGhe, @LoaiGhe, @MaPhongChieu)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaGhe", ghengoi.MaGhe);
                        cmd.Parameters.AddWithValue("@SoGhe", ghengoi.SoGhe);
                        cmd.Parameters.AddWithValue("@LoaiGhe", ghengoi.LoaiGhe);
                        cmd.Parameters.AddWithValue("@MaPhongChieu", ghengoi.MaPhongChieu);



                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                GheNgoiModel ghengoi = (GheNgoiModel)model;
                string MaGhe = ghengoi.MaGhe;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deleteghengoiQuery = "DELETE FROM GheNgoi WHERE MaGhe = @MaGhe";
                            using (SqlCommand deleteghengoiCmd = new SqlCommand(deleteghengoiQuery, connection, transaction))
                            {
                                deleteghengoiCmd.Parameters.AddWithValue("@MaGhe", MaGhe);
                                deleteghengoiCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from GheNgoi", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    GheNgoiModel model = new GheNgoiModel();
                    model.MaGhe = reader["MaGhe"].ToString();
                    model.SoGhe = int.Parse(reader["SoGhe"].ToString());
                    model.LoaiGhe = reader["LoaiGhe"].ToString();
                    model.MaPhongChieu = reader["MaPhongChieu"].ToString();


                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaGhe)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaGhe)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                GheNgoiModel ghengoi = (GheNgoiModel)model;
                string query = "UPDATE GheNgoi SET SoGhe = @SoGhe, LoaiGhe = @LoaiGhe, MaPhongChieu = @MaPhongChieu WHERE MaGhe = @MaGhe";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaGhe", ghengoi.MaGhe);
                        cmd.Parameters.AddWithValue("@SoGhe", ghengoi.SoGhe);
                        cmd.Parameters.AddWithValue("@LoaiGhe", ghengoi.LoaiGhe);
                        cmd.Parameters.AddWithValue("@MaPhongChieu", ghengoi.MaPhongChieu);




                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaGhe)
        {
            return true;
        }
        public bool Read(Object MaGhe)
        {

            return true;
        }

        IModel IController.Read(object MaGhe)
        {
            throw new NotImplementedException();
        }


    }
}

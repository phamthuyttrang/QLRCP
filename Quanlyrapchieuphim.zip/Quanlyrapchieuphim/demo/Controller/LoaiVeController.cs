﻿using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal class LoaiVeController : IController
    {
        private List<IModel> _items;
        public List<LoaiVeModel> GetAllLoaiVes()
        {
            List<LoaiVeModel> loaives = new List<LoaiVeModel>();
            string query = "SELECT * FROM LoaiVe";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                LoaiVeModel loaive = new LoaiVeModel
                {
                    MaLoaiVe = row["MaLoaiVe"].ToString(),
                    TenLoaiVe = row["TenLoaiVe"].ToString(),
                    
                };



                loaives.Add(loaive);
            }

            return loaives;
        }
        public LoaiVeController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                LoaiVeModel loaive = (LoaiVeModel)model;
                string query = "INSERT INTO LoaiVe (MaLoaiVe, TenLoaiVe) VALUES (@MaLoaiVe, @TenLoaiVe)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaLoaiVe", loaive.MaLoaiVe);
                        cmd.Parameters.AddWithValue("@TenLoaiVe", loaive.TenLoaiVe);
                        
                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                LoaiVeModel loaive = (LoaiVeModel)model;
                string MaLoaiVe = loaive.MaLoaiVe;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deleteloaiveQuery = "DELETE FROM LoaiVe WHERE MaLoaiVe = @MaLoaiVe";
                            using (SqlCommand deleteloaiveCmd = new SqlCommand(deleteloaiveQuery, connection, transaction))
                            {
                                deleteloaiveCmd.Parameters.AddWithValue("@MaLoaiVe", MaLoaiVe);
                                deleteloaiveCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from LoaiVe", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    LoaiVeModel model = new LoaiVeModel();
                    model.MaLoaiVe = reader["MaLoaiVe"].ToString();
                    model.TenLoaiVe = reader["TenLoaiVe"].ToString();
                    
                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaLoaiVe)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaLoaiVe)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                LoaiVeModel loaive = (LoaiVeModel)model;
                string query = "UPDATE LoaiVe SET TenLoaiVe = @TenLoaiVe WHERE MaLoaiVe = @MaLoaiVe";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaLoaiVe", loaive.MaLoaiVe);
                        cmd.Parameters.AddWithValue("@TenLoaiVe", loaive.TenLoaiVe);
                        


                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaLoaiVe)
        {
            return true;
        }
        public bool Read(Object MaLoaiVe)
        {

            return true;
        }

        IModel IController.Read(object MaLoaiVe)
        {
            throw new NotImplementedException();
        }


    }
}

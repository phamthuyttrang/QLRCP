﻿using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal class ThongTinPhimController : IController
    {
        private List<IModel> _items;
        public List<ThongTinPhimModel> GetAllThongTinPhims()
        {
            List<ThongTinPhimModel> thongtinphims = new List<ThongTinPhimModel>();
            string query = "SELECT * FROM ThongTinPhim";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                ThongTinPhimModel thongtinphim = new ThongTinPhimModel
                {
                    MaPhim = row["MaPhim"].ToString(),
                    TenPhim = row["TenPhim"].ToString(),
                    TheLoai = row["TheLoai"].ToString(),
                    DoTuoi = int.Parse(row["DoTuoi"].ToString()),
                    ThoiLuong = int.Parse(row["ThoiLuong"].ToString()),
                    MaNhaCungCap = row["MaNhaCungCap"].ToString(),
                };



                thongtinphims.Add(thongtinphim);
            }

            return thongtinphims;
        }
        public ThongTinPhimController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                ThongTinPhimModel thongtinphim = (ThongTinPhimModel)model;
                string query = "INSERT INTO ThongTinPhim (MaPhim, TenPhim, TheLoai, DoTuoi, ThoiLuong, MaNhaCungCap) VALUES (@MaPhim, @TenPhim, @TheLoai, @DoTuoi, @ThoiLuong, @MaNhaCungCap)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaPhim", thongtinphim.MaPhim);
                        cmd.Parameters.AddWithValue("@TenPhim", thongtinphim.TenPhim);
                        cmd.Parameters.AddWithValue("@TheLoai", thongtinphim.TheLoai);
                        cmd.Parameters.AddWithValue("@DoTuoi", thongtinphim.DoTuoi);
                        cmd.Parameters.AddWithValue("@ThoiLuong", thongtinphim.ThoiLuong);
                        cmd.Parameters.AddWithValue("@MaNhaCungCap", thongtinphim.MaNhaCungCap);
                        

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                ThongTinPhimModel thongtinphim = (ThongTinPhimModel)model;
                string MaPhim = thongtinphim.MaPhim;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deletethongtinphimQuery = "DELETE FROM ThongTinPhim WHERE MaPhim = @MaPhim";
                            using (SqlCommand deletethongtinphimCmd = new SqlCommand(deletethongtinphimQuery, connection, transaction))
                            {
                                deletethongtinphimCmd.Parameters.AddWithValue("@MaPhim", MaPhim);
                                deletethongtinphimCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from ThongTinPhim", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ThongTinPhimModel model = new ThongTinPhimModel();
                    model.MaPhim = reader["MaPhim"].ToString();
                    model.TenPhim = reader["TenPhim"].ToString();
                    model.TheLoai = reader["TheLoai"].ToString();
                    model.DoTuoi = int.Parse(reader["DoTuoi"].ToString());
                    model.ThoiLuong = int.Parse(reader["ThoiLuong"].ToString());          
                    model.MaNhaCungCap = reader["MaNhaCungCap"].ToString();
                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaPhim)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaPhim)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                ThongTinPhimModel thongtinphim = (ThongTinPhimModel)model;
                string query = "UPDATE ThongTinPhim SET TenPhim = @TenPhim, TheLoai = @TheLoai, DoTuoi = @DoTuoi, ThoiLuong = @ThoiLuong, MaNhaCungCap = @MaNhaCungCap WHERE MaPhim = @MaPhim";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaPhim", thongtinphim.MaPhim);
                        cmd.Parameters.AddWithValue("@TenPhim", thongtinphim.TenPhim);
                        cmd.Parameters.AddWithValue("@TheLoai", thongtinphim.TheLoai);
                        cmd.Parameters.AddWithValue("@DoTuoi", thongtinphim.DoTuoi);
                        cmd.Parameters.AddWithValue("@ThoiLuong", thongtinphim.ThoiLuong);
                        cmd.Parameters.AddWithValue("@MaNhaCungCap", thongtinphim.MaNhaCungCap);
                       


                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaPhim)
        {
            return true;
        }
        public bool Read(Object MaPhim)
        {

            return true;
        }

        IModel IController.Read(object MaPhim)
        {
            throw new NotImplementedException();
        }


    }
}

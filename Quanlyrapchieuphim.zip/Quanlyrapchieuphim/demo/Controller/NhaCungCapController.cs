﻿using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal class NhaCungCapController : IController
    {
        private List<IModel> _items;
        public List<NhaCungCapModel> GetAllNhaCungCaps()
        {
            List<NhaCungCapModel> nhacungcaps = new List<NhaCungCapModel>();
            string query = "SELECT * FROM NhaCungCap";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                NhaCungCapModel nhacungcap = new NhaCungCapModel
                {
                    MaNhaCungCap = row["MaNhaCungCap"].ToString(),
                    TenNhaCungCap = row["TenNhaCungCap"].ToString(),
                    DiaChi = row["DiaChi"].ToString(),
                    SoDienThoai = row["SoDienThoai"].ToString(),
                    Email = row["Email"].ToString(),
                   
                   
                };



                nhacungcaps.Add(nhacungcap);
            }

            return nhacungcaps;
        }
        public NhaCungCapController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                NhaCungCapModel nhacungcap = (NhaCungCapModel)model;
                string query = "INSERT INTO NhaCungCap (MaNhaCungCap, TenNhaCungCap, DiaChi, SoDienThoai, Email) VALUES (@MaNhaCungCap, @TenNhaCungCap, @DiaChi, @SoDienThoai, @Email)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaNhaCungCap", nhacungcap.MaNhaCungCap);
                        cmd.Parameters.AddWithValue("@TenNhaCungCap", nhacungcap.TenNhaCungCap);
                        cmd.Parameters.AddWithValue("@DiaChi", nhacungcap.DiaChi);
                        cmd.Parameters.AddWithValue("@SoDienThoai", nhacungcap.SoDienThoai);
                        cmd.Parameters.AddWithValue("@Email", nhacungcap.Email);
                        

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                NhaCungCapModel nhacungcap = (NhaCungCapModel)model;
                string MaNhaCungCap = nhacungcap.MaNhaCungCap;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deletenhacungcapQuery = "DELETE FROM NhaCungCap WHERE MaNhaCungCap = @MaNhaCungCap";
                            using (SqlCommand deletenhacungcapCmd = new SqlCommand(deletenhacungcapQuery, connection, transaction))
                            {
                                deletenhacungcapCmd.Parameters.AddWithValue("@MaNhaCungCap", MaNhaCungCap);
                                deletenhacungcapCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from NhaCungCap", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    NhaCungCapModel model = new NhaCungCapModel();
                    model.MaNhaCungCap = reader["MaNhaCungCap"].ToString();
                    model.TenNhaCungCap = reader["TenNhaCungCap"].ToString();
                    model.DiaChi = reader["DiaChi"].ToString();
                    model.SoDienThoai = reader["SoDienThoai"].ToString();
                    model.Email = reader["Email"].ToString();
                   
                    
                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaNhaCungCap)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaNhaCungCap)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                NhaCungCapModel nhacungcap = (NhaCungCapModel)model;
                string query = "UPDATE NhaCungCap SET TenNhaCungCap = @TenNhaCungCap, DiaChi = @DiaChi, SoDienThoai = @SoDienThoai, Email = @Email WHERE MaNhaCungCap = @MaNhaCungCap";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaNhaCungCap", nhacungcap.MaNhaCungCap);
                        cmd.Parameters.AddWithValue("@TenNhaCungCap", nhacungcap.TenNhaCungCap);
                        cmd.Parameters.AddWithValue("@DiaChi", nhacungcap.DiaChi);
                        cmd.Parameters.AddWithValue("@SoDienThoai", nhacungcap.SoDienThoai);
                        cmd.Parameters.AddWithValue("@Email", nhacungcap.Email);
                        


                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaNhaCungCap)
        {
            return true;
        }
        public bool Read(Object MaNhaCungCap)
        {

            return true;
        }

        IModel IController.Read(object MaNhaCungCap)
        {
            throw new NotImplementedException();
        }


    }
}

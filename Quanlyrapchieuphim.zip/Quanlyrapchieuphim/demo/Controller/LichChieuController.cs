﻿using demo.Controller;
using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo.Controller
{
    internal class LichChieuController : IController
    {
        private List<IModel> _items;
        public List<LichChieuModel> GetAllLichChieus()
        {
            List<LichChieuModel> lichchieus = new List<LichChieuModel>();
            string query = "SELECT * FROM LichChieu";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                LichChieuModel lichchieu = new LichChieuModel
                {
                    MaLichChieu = row["MaLichChieu"].ToString(),
                    GioChieu = DateTime.Parse(row["GioChieu"].ToString()),
                    MaPhim = row["MaPhim"].ToString(),
                    MaPhongChieu = row["MaPhongChieu"].ToString(),

                };



                lichchieus.Add(lichchieu);
            }

            return lichchieus;
        }
        public LichChieuController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                LichChieuModel lichchieu = (LichChieuModel)model;
                string query = "INSERT INTO LichChieu (MaLichChieu, GioChieu, MaPhim, MaPhongChieu) VALUES (@MaLichChieu, @GioChieu, @MaPhim, @MaPhongChieu)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaLichChieu", lichchieu.MaLichChieu);
                        cmd.Parameters.AddWithValue("@GioChieu", lichchieu.GioChieu);
                        cmd.Parameters.AddWithValue("@MaPhim", lichchieu.MaPhim);
                        cmd.Parameters.AddWithValue("@MaPhongChieu", lichchieu.MaPhongChieu);


                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                LichChieuModel lichchieu = (LichChieuModel)model;
                string MaLichChieu = lichchieu.MaLichChieu;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deletelichchieuQuery = "DELETE FROM LichChieu WHERE MaLichChieu = @MaLichChieu";
                            using (SqlCommand deletelichchieuCmd = new SqlCommand(deletelichchieuQuery, connection, transaction))
                            {
                                deletelichchieuCmd.Parameters.AddWithValue("@MaLichChieu", MaLichChieu);
                                deletelichchieuCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from LichChieu", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    LichChieuModel model = new LichChieuModel();
                    model.MaLichChieu = reader["MaLichChieu"].ToString();
                    model.GioChieu = DateTime.Parse(reader["GioChieu"].ToString());
                    model.MaPhim = reader["MaPhim"].ToString();
                    model.MaPhongChieu = reader["MaPhongChieu"].ToString();
                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaLichChieu)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaLichChieu)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                LichChieuModel lichchieu = (LichChieuModel)model;
                string query = "UPDATE LichChieu SET GioChieu = @GioChieu, MaPhim = @MaPhim, MaPhongChieu = @MaPhongChieu WHERE MaLichChieu = @MaLichChieu";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaLichChieu", lichchieu.MaLichChieu);
                        cmd.Parameters.AddWithValue("@GioChieu", lichchieu.GioChieu);
                        cmd.Parameters.AddWithValue("@MaPhim", lichchieu.MaPhim);
                        cmd.Parameters.AddWithValue("@MaPhongChieu", lichchieu.MaPhongChieu);



                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaLichChieu)
        {
            return true;
        }

        

        public bool Read(Object MaLichChieu)
        {

            return true;
        }


        IModel IController.Read(object MaLichChieu)
        {
            throw new NotImplementedException();
        }


    }
}

﻿using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal class PhongChieuController : IController
    {
        private List<IModel> _items;
        public List<PhongChieuModel> GetAllPhongChieus()
        {
            List<PhongChieuModel> phongchieus = new List<PhongChieuModel>();
            string query = "SELECT * FROM PhongChieu";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                PhongChieuModel phongchieu = new PhongChieuModel
                {
                    MaPhongChieu = row["MaPhongChieu"].ToString(),
                    TenPhongChieu = row["TenPhongChieu"].ToString(),

                };



                phongchieus.Add(phongchieu);
            }

            return phongchieus;
        }
        public PhongChieuController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                PhongChieuModel phongchieu = (PhongChieuModel)model;
                string query = "INSERT INTO PhongChieu (MaPhongChieu, TenPhongChieu) VALUES (@MaPhongChieu, @TenPhongChieu)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaPhongChieu", phongchieu.MaPhongChieu);
                        cmd.Parameters.AddWithValue("@TenPhongChieu", phongchieu.TenPhongChieu);

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                PhongChieuModel phongchieu = (PhongChieuModel)model;
                string MaPhongChieu = phongchieu.MaPhongChieu;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deletephongchieuQuery = "DELETE FROM PhongChieu WHERE MaPhongChieu = @MaPhongChieu";
                            using (SqlCommand deletephongchieuCmd = new SqlCommand(deletephongchieuQuery, connection, transaction))
                            {
                                deletephongchieuCmd.Parameters.AddWithValue("@MaPhongChieu", MaPhongChieu);
                                deletephongchieuCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from PhongChieu", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    PhongChieuModel model = new PhongChieuModel();
                    model.MaPhongChieu = reader["MaPhongChieu"].ToString();
                    model.TenPhongChieu = reader["TenPhongChieu"].ToString();

                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaPhongChieu)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaPhongChieu)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                PhongChieuModel phongchieu = (PhongChieuModel)model;
                string query = "UPDATE PhongChieu SET TenPhongChieu = @TenPhongChieu WHERE MaPhongChieu = @MaPhongChieu";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaPhongChieu", phongchieu.MaPhongChieu);
                        cmd.Parameters.AddWithValue("@TenPhongChieu", phongchieu.TenPhongChieu);



                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaPhongChieu)
        {
            return true;
        }
        public bool Read(Object MaPhongChieu)
        {

            return true;
        }

        IModel IController.Read(object MaPhongChieu)
        {
            throw new NotImplementedException();
        }


    }
}

﻿using demo.Model;
using demo.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Controller
{
    internal class KhachHangController : IController
    {
        private List<IModel> _items;
        public List<KhachHangModel> GetAllKhachHangs()
        {
            List<KhachHangModel> khachhangs = new List<KhachHangModel>();
            string query = "SELECT * FROM KhachHang";

            DataTable dataTable = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dataTable.Rows)
            {
                KhachHangModel khachhang = new KhachHangModel
                {
                    MaKhachHang = row["MaKhachHang"].ToString(),
                    HoTen = row["HoTen"].ToString(),
                    GioiTinh = row["GioiTinh"].ToString(),
                    Email = row["Email"].ToString(),
                    SoDienThoai = row["SoDienThoai"].ToString(),
                    DiemTichLuy = int.Parse(row["DiemTichLuy"].ToString()),
                    LoaiThanhVien = row["LoaiThanhVien"].ToString(),
                };



                khachhangs.Add(khachhang);
            }

            return khachhangs;
        }
        public KhachHangController()
        {
            _items = new List<IModel>();
        }

        public List<IModel> Items => this._items;

        public bool Create(IModel model)
        {
            try
            {
                KhachHangModel khachhang = (KhachHangModel)model;
                string query = "INSERT INTO KhachHang (MaKhachHang, HoTen, GioiTinh, Email, SoDienThoai, DiemTichLuy, LoaiThanhVien) VALUES (@MaKhachHang, @HoTen, @GioiTinh, @Email, @SoDienThoai, @DiemTichLuy, @LoaiThanhVien)";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaKhachHang", khachhang.MaKhachHang);
                        cmd.Parameters.AddWithValue("@HoTen", khachhang.HoTen);
                        cmd.Parameters.AddWithValue("@GioiTinh", khachhang.SoDienThoai);
                        cmd.Parameters.AddWithValue("@Email", khachhang.Email);
                        cmd.Parameters.AddWithValue("@SoDienThoai", khachhang.SoDienThoai);
                        cmd.Parameters.AddWithValue("@DiemTichLuy", khachhang.DiemTichLuy);
                        cmd.Parameters.AddWithValue("@LoaiThanhVien", khachhang.LoaiThanhVien);

                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }

            }
            catch (Exception ex)
            {


                Console.WriteLine(ex.Message);
                return false;
            }
        }



        public bool Delete(IModel model)
        {
            try
            {
                KhachHangModel khachhang = (KhachHangModel)model;
                string MaKhachHang = khachhang.MaKhachHang;

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {



                            string deletekhachhangQuery = "DELETE FROM KhachHang WHERE MaKhachHang = @MaKhachHang";
                            using (SqlCommand deletekhachhangCmd = new SqlCommand(deletekhachhangQuery, connection, transaction))
                            {
                                deletekhachhangCmd.Parameters.AddWithValue("@MaKhachHang", MaKhachHang);
                                deletekhachhangCmd.ExecuteNonQuery();
                            }

                            transaction.Commit();
                            return true;
                        }
                        catch (Exception ex)
                        {

                            transaction.Rollback();
                            Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }



        public bool Load()
        {
            try
            {
                SqlConnection conn = DatabaseHelper.GetConnection();
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from KhachHang", conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    KhachHangModel model = new KhachHangModel();
                    model.MaKhachHang = reader["MaKhachHang"].ToString();
                    model.HoTen = reader["HoTen"].ToString();
                    model.GioiTinh = reader["GioiTinh"].ToString();
                    model.Email = reader["Email"].ToString();
                    model.SoDienThoai = reader["SoDienThoai"].ToString();
                    model.DiemTichLuy = int.Parse(reader["DiemTichLuy"].ToString());
                    model.LoaiThanhVien = reader["LoaiThanhVien"].ToString();
                    this._items.Add(model);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public bool Load(object MaKhachHang)
        {
            throw new NotImplementedException();
        }

        public IModel Read(IModel MaKhachHang)
        {
            throw new NotImplementedException();
        }

        public bool Update(IModel model)
        {
            try
            {
                KhachHangModel khachhang = (KhachHangModel)model;
                string query = "UPDATE KhachHang SET HoTen = @HoTen, GioiTinh = @GioiTinh, Email = @Email, SoDienThoai = @SoDienThoai, DiemTichLuy = @DiemTichLuy, LoaiThanhVien = @LoaiThanhVien WHERE MaKhachHang = @MaKhachHang";

                using (SqlConnection connection = DatabaseHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaKhachHang", khachhang.MaKhachHang);
                        cmd.Parameters.AddWithValue("@HoTen", khachhang.HoTen);
                        cmd.Parameters.AddWithValue("@GioiTinh", khachhang.GioiTinh);
                        cmd.Parameters.AddWithValue("@Email", khachhang.Email);
                        cmd.Parameters.AddWithValue("@SoDienThoai", khachhang.SoDienThoai);
                        cmd.Parameters.AddWithValue("@DiemTichLuy", khachhang.DiemTichLuy);
                        cmd.Parameters.AddWithValue("@LoaiThanhVien", khachhang.LoaiThanhVien);


                        connection.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                return false;
            }
        }
        public bool IsExist(object MaKhachHang)
        {
            return true;
        }
        public bool Read(Object MaKhachHang)
        {

            return true;
        }

        IModel IController.Read(object MaKhachHang)
        {
            throw new NotImplementedException();
        }


    }
}

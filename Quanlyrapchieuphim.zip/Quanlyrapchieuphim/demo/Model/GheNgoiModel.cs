﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal class GheNgoiModel : IModel
    {
        public string MaGhe { get; set; }

        public int SoGhe { get; set; }
        public string LoaiGhe { get; set; }

        public string MaPhongChieu { get; set; }



        public bool IsValidate()
        {
            return true;
        }
    }
}

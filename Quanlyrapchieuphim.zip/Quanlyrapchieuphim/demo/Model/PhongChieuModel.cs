﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal class PhongChieuModel : IModel
    {
        public string MaPhongChieu { get; set; }

        public string TenPhongChieu { get; set; }



        public bool IsValidate()
        {
            return true;
        }
    }
}

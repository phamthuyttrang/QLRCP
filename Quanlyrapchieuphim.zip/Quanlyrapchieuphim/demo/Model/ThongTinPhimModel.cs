﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal class ThongTinPhimModel : IModel
    {
        public string MaPhim { get; set; }

        public string TenPhim { get; set; }
        public string TheLoai { get; set; }

        public int DoTuoi { get; set; }

        public int ThoiLuong { get; set; }

        public string MaNhaCungCap { get; set; }

        


        public bool IsValidate()
        {
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal class VeModel : IModel
    {
        public string MaVe { get; set; }

        public string TenVe { get; set; }
        public decimal GiaVe { get; set; }

        public string MaLoaiVe { get; set; }



        public bool IsValidate()
        {
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal class LichChieuModel : IModel
    {
        public string MaLichChieu { get; set; }

        public DateTime GioChieu { get; set; }
        public string MaPhim { get; set; }

        public string MaPhongChieu { get; set; }



        public bool IsValidate()
        {
            return true;
        }
    }
}

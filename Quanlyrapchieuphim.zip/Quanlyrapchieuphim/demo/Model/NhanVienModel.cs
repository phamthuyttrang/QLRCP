﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal class NhanVienModel : IModel
    {
        public string MaNhanVien { get; set; }

        public string TenNhanVien { get; set; }
        public string MatKhau { get; set; }

        public string ChucVu { get; set; }



        public bool IsValidate()
        {
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal class LoaiVeModel : IModel
    {
        public string MaLoaiVe { get; set; }

        public string TenLoaiVe { get; set; }
      


        public bool IsValidate()
        {
            return true;
        }
    }
}

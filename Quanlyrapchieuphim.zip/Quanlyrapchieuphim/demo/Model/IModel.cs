﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo.Model
{
    internal interface IModel
    {
        //True: neu du lieu hop
        //Flase: neu du lieu khong hop le
        bool IsValidate();
    }
}
